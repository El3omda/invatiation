<?php $__env->startSection('title'); ?>
    <?php echo e(__('inc.n20')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <div style="width: 90%;position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);text-align: center;">
            <img width="200px" src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="logo">
            <h3 class="fw-bold mt-3">
                <?php echo e(__('home.h111')); ?>

            </h3>
        </div>

    </div>

    <footer class="text-center py-3 text-white fw-bold mt-5"
        style="position: absolute;bottom: 0;left: 0;right: 0;background: linear-gradient(90deg, rgba(250,44,99,1) 0%, rgba(251,167,15,1) 100%);">
        <?php echo e(__('inc.n4')); ?> <?php echo e(date('Y')); ?>

    </footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\invite\resources\views/pages/about.blade.php ENDPATH**/ ?>