<?php

return [

    'n0' => 'Create An Event Invitation | Almiqias',
    'n1' => 'Home',
    'n2' => 'About Us',
    'n20' => 'About Us | Almiqias',
    'n3' => 'Contact Us',
    'n30' => 'Contact Us | Almiqias',
    'n4' => 'All Rights Reserved Almiqias ©',
    'n5' => 'Contact',
    'n6' => 'Us',
    'n7' => 'We Are Always Happy to Communicate with You And We Will Get Back To You As Soon As Possible',
    'n8' => 'Name',
    'n9' => 'Email',
    'n10' => 'Subject',
    'n11' => 'Message',
    'n12' => 'Send',
    'n13' => 'Create Your Own Invitation',

];
