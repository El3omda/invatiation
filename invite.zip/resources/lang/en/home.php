<?php

return [

    'h1' => 'Create an invitation for your event and share it with your loved ones',
    'h111' => 'We let you to create invitations for your events, with the ability to share the invitation link with your loved ones.',
    'h2' => 'Create An Event Invitation',

];
